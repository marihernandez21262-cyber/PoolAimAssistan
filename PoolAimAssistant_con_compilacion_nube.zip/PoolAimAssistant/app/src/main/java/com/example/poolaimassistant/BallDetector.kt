
package com.example.poolaimassistant

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.PI
import kotlin.math.sqrt

data class DetectedBall(
    val x: Int,
    val y: Int,
    val radius: Int,
    val color: Int
)

data class ScreenBall(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Int
)

object AimData {
    @Volatile
    var balls: List<ScreenBall> = emptyList()

    @Volatile
    var whiteBall: ScreenBall? = null
}

object TableBounds {
    // Límites aproximados del paño azul según tu captura.
    @Volatile var left = 0.195f
    @Volatile var right = 0.805f
    @Volatile var top = 0.235f
    @Volatile var bottom = 0.915f
}

class BallDetector {

    fun detect(bitmap: Bitmap): List<DetectedBall> {
        val width = bitmap.width
        val height = bitmap.height

        if (width < 30 || height < 30) {
            AimData.balls = emptyList()
            AimData.whiteBall = null
            return emptyList()
        }

        val left = (width * TableBounds.left).toInt()
            .coerceIn(0, width - 1)
        val right = (width * TableBounds.right).toInt()
            .coerceIn(left + 1, width)
        val top = (height * TableBounds.top).toInt()
            .coerceIn(0, height - 1)
        val bottom = (height * TableBounds.bottom).toInt()
            .coerceIn(top + 1, height)

        val step = 2
        val visited = HashSet<Int>()
        val results = mutableListOf<DetectedBall>()

        fun isFelt(color: Int): Boolean {
            val r = Color.red(color)
            val g = Color.green(color)
            val b = Color.blue(color)
            return g > r * 1.10f && g > b * 1.08f
        }

        fun isBallPixel(color: Int): Boolean {
            val r = Color.red(color)
            val g = Color.green(color)
            val b = Color.blue(color)
            val brightness = (r + g + b) / 3
            val saturation = maxOf(r, g, b) - minOf(r, g, b)

            return !isFelt(color) &&
                brightness > 105 &&
                (saturation > 25 || brightness > 205)
        }

        for (y in top until bottom step step) {
            for (x in left until right step step) {
                val index = y * width + x

                if (index in visited) continue
                if (!isBallPixel(bitmap.getPixel(x, y))) continue

                val queue = ArrayDeque<Pair<Int, Int>>()
                val points = mutableListOf<Pair<Int, Int>>()

                queue.add(x to y)
                visited.add(index)

                while (queue.isNotEmpty() && points.size < 250) {
                    val (px, py) = queue.removeFirst()
                    points.add(px to py)

                    for (dy in -step..step step step) {
                        for (dx in -step..step step step) {
                            if (dx == 0 && dy == 0) continue

                            val nx = px + dx
                            val ny = py + dy

                            if (nx !in left until right ||
                                ny !in top until bottom) continue

                            val nextIndex = ny * width + nx

                            if (nextIndex in visited) continue

                            if (isBallPixel(bitmap.getPixel(nx, ny))) {
                                visited.add(nextIndex)
                                queue.add(nx to ny)
                            }
                        }
                    }
                }

                if (points.size !in 8..249) continue

                val minX = points.minOf { it.first }
                val maxX = points.maxOf { it.first }
                val minY = points.minOf { it.second }
                val maxY = points.maxOf { it.second }

                val boxWidth = maxX - minX + step
                val boxHeight = maxY - minY + step
                val aspect = boxWidth.toFloat() /
                    boxHeight.coerceAtLeast(1)

                val area = points.size * step * step
                val radius = sqrt(area / PI).toInt()

                if (aspect !in 0.65f..1.45f) continue
                if (radius !in 4..22) continue

                val centerX = points.map { it.first }.average().toInt()
                val centerY = points.map { it.second }.average().toInt()

                results.add(
                    DetectedBall(
                        centerX,
                        centerY,
                        radius,
                        bitmap.getPixel(centerX, centerY)
                    )
                )
            }
        }

        val filtered = results
            .distinctBy { "${it.x / 12}_${it.y / 12}" }
            .take(16)

        val white = filtered
            .filter {
                Color.red(it.color) > 185 &&
                Color.green(it.color) > 185 &&
                Color.blue(it.color) > 185
            }
            .minByOrNull {
                val dx = it.x - width / 2
                val dy = it.y - height / 2
                dx * dx + dy * dy
            }

        AimData.whiteBall = white?.let {
            ScreenBall(
                it.x.toFloat() / width,
                it.y.toFloat() / height,
                it.radius.toFloat() / width,
                it.color
            )
        }

        AimData.balls = filtered
            .filterNot { it == white }
            .map {
                ScreenBall(
                    it.x.toFloat() / width,
                    it.y.toFloat() / height,
                    it.radius.toFloat() / width,
                    it.color
                )
            }

        return filtered
    }
}
