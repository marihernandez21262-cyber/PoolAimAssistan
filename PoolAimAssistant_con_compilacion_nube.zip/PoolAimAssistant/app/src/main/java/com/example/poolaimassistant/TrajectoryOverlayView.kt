package com.example.poolaimassistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class TrajectoryOverlayView(context: Context) : View(context) {

    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.YELLOW
    }

    private val whiteBallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.WHITE
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.CYAN
    }

    private var balls: List<ScreenBall> = emptyList()
    private var whiteBall: ScreenBall? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun updateBalls(newBalls: List<ScreenBall>) {
        balls = newBalls.toList()
        whiteBall = AimData.whiteBall
        invalidate()
    }

    fun hideGuide() {
        balls = emptyList()
        whiteBall = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val left = width * TableBounds.left
        val right = width * TableBounds.right
        val top = height * TableBounds.top
        val bottom = height * TableBounds.bottom

        val saveCount = canvas.save()
        canvas.clipRect(left, top, right, bottom)

        fun drawBall(ball: ScreenBall, paint: Paint) {
            val x = ball.x * width
            val y = ball.y * height
            val radius = (ball.radius * width).coerceAtLeast(8f)

            if (x in left..right && y in top..bottom) {
                canvas.drawCircle(x, y, radius, paint)
            }
        }

        whiteBall?.let {
            drawBall(it, whiteBallPaint)
        }

        for (ball in balls) {
            drawBall(ball, ballPaint)
        }

        // Línea provisional entre la bola blanca y la bola objetivo más cercana.
        val cue = whiteBall
        if (cue != null && balls.isNotEmpty()) {
            val target = balls.minByOrNull {
                val dx = it.x - cue.x
                val dy = it.y - cue.y
                dx * dx + dy * dy
            }

            if (target != null) {
                canvas.drawLine(
                    cue.x * width,
                    cue.y * height,
                    target.x * width,
                    target.y * height,
                    linePaint
                )
            }
        }

        canvas.restoreToCount(saveCount)
    }
}