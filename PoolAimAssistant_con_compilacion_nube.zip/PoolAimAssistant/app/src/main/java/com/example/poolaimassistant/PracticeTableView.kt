
package com.example.poolaimassistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

class PracticeTableView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var ballX = 0f
    private var ballY = 0f
    private var aimX = 0f
    private var aimY = 0f

    private var initialized = false
    private var selectedBall = 0

    private var left = 0f
    private var top = 0f
    private var right = 0f
    private var bottom = 0f
    private var radius = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val tableWidth = width * 0.90f
        val tableHeight = tableWidth / 2f

        val tableLeft = (width - tableWidth) / 2f
        val tableTop = (height - tableHeight) / 2f

        val frame = RectF(
            tableLeft, tableTop,
            tableLeft + tableWidth,
            tableTop + tableHeight
        )

        paint.shader = LinearGradient(
            frame.left, frame.top,
            frame.right, frame.bottom,
            intArrayOf(
                Color.rgb(115, 57, 25),
                Color.rgb(65, 30, 15),
                Color.rgb(135, 72, 32)
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(frame, 18f, 18f, paint)
        paint.shader = null

        val rail = RectF(
            frame.left + 18f,
            frame.top + 18f,
            frame.right - 18f,
            frame.bottom - 18f
        )

        paint.color = Color.rgb(15, 75, 48)
        canvas.drawRoundRect(rail, 10f, 10f, paint)

        left = rail.left + 15f
        top = rail.top + 15f
        right = rail.right - 15f
        bottom = rail.bottom - 15f

        paint.shader = LinearGradient(
            left, top, right, bottom,
            Color.rgb(15, 125, 76),
            Color.rgb(5, 85, 51),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(left, top, right, bottom, paint)
        paint.shader = null

        radius = min(width, height) * 0.027f

        paint.color = Color.BLACK

        val pockets = listOf(
            left to top,
            (left + right) / 2f to top,
            right to top,
            left to bottom,
            (left + right) / 2f to bottom,
            right to bottom
        )

        for ((x, y) in pockets) {
            canvas.drawCircle(x, y, radius * 1.25f, paint)
        }

        paint.color = Color.rgb(235, 205, 145)

        for (i in 1..5) {
            val x = left + (right - left) * i / 6f
            canvas.drawCircle(x, top - 7f, 3f, paint)
            canvas.drawCircle(x, bottom + 7f, 3f, paint)
        }

        if (!initialized) {
            ballX = left + (right - left) * 0.28f
            ballY = (top + bottom) / 2f

            aimX = left + (right - left) * 0.70f
            aimY = (top + bottom) / 2f

            initialized = true
        }

        drawTrajectory(canvas)

        drawBall(canvas, aimX, aimY, radius * 0.72f, Color.YELLOW)
        drawBall(canvas, ballX, ballY, radius * 0.72f, Color.WHITE)
    }

    private fun drawTrajectory(canvas: Canvas) {
        var dx = aimX - ballX
        var dy = aimY - ballY

        val length = hypot(dx, dy)
        if (length < 1f) return

        dx /= length
        dy /= length

        var x = ballX
        var y = ballY

        val inset = radius * 0.8f

        val minX = left + inset
        val maxX = right - inset
        val minY = top + inset
        val maxY = bottom - inset

        val colors = intArrayOf(
            Color.WHITE,
            Color.CYAN,
            Color.RED
        )

        for (segment in 0..2) {
            var tx = Float.POSITIVE_INFINITY
            var ty = Float.POSITIVE_INFINITY

            if (dx > 0f) tx = (maxX - x) / dx
            if (dx < 0f) tx = (minX - x) / dx
            if (dy > 0f) ty = (maxY - y) / dy
            if (dy < 0f) ty = (minY - y) / dy

            val distance = min(
                if (tx > 0f) tx else Float.POSITIVE_INFINITY,
                if (ty > 0f) ty else Float.POSITIVE_INFINITY
            )

            if (!distance.isFinite()) break

            val nextX = x + dx * distance
            val nextY = y + dy * distance

            paint.color = colors[segment]
            paint.strokeWidth = 5f
            paint.style = Paint.Style.STROKE

            canvas.drawLine(x, y, nextX, nextY, paint)

            paint.style = Paint.Style.FILL

            if (segment < 2) {
                paint.color = Color.YELLOW
                canvas.drawCircle(nextX, nextY, 7f, paint)
            }

            x = nextX
            y = nextY

            if (tx < ty) {
                dx = -dx
            } else {
                dy = -dy
            }
        }
    }

    private fun drawBall(
        canvas: Canvas,
        x: Float,
        y: Float,
        r: Float,
        color: Int
    ) {
        paint.color = Color.BLACK
        canvas.drawCircle(x + 3f, y + 4f, r, paint)

        paint.shader = LinearGradient(
            x - r, y - r,
            x + r, y + r,
            Color.WHITE,
            color,
            Shader.TileMode.CLAMP
        )

        canvas.drawCircle(x, y, r, paint)
        paint.shader = null

        paint.color = Color.WHITE
        canvas.drawCircle(
            x - r * 0.3f,
            y - r * 0.3f,
            r * 0.18f,
            paint
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val hitRadius = radius * 1.8f

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val distanceWhite =
                    hypot(event.x - ballX, event.y - ballY)

                val distanceYellow =
                    hypot(event.x - aimX, event.y - aimY)

                selectedBall = when {
                    distanceWhite <= hitRadius &&
                    distanceWhite <= distanceYellow -> 1

                    distanceYellow <= hitRadius -> 2

                    else -> 0
                }

                return selectedBall != 0
            }

            MotionEvent.ACTION_MOVE -> {
                val inset = radius * 1.5f

                when (selectedBall) {
                    1 -> {
                        ballX = event.x.coerceIn(
                            left + inset, right - inset
                        )
                        ballY = event.y.coerceIn(
                            top + inset, bottom - inset
                        )
                    }

                    2 -> {
                        aimX = event.x.coerceIn(
                            left + inset, right - inset
                        )
                        aimY = event.y.coerceIn(
                            top + inset, bottom - inset
                        )
                    }
                }

                invalidate()
                return true
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                selectedBall = 0
                performClick()
                return true
            }
        }

        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
