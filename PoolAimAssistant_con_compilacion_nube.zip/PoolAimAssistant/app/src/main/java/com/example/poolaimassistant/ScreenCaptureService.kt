
package com.example.poolaimassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock

class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null

    private var analysisThread: HandlerThread? = null
    private var analysisHandler: Handler? = null

    private val detector = BallDetector()
    private var lastAnalysisTime = 0L

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            releaseCapture(false)
            stopSelf()
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        if (projection != null) {
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("resultData", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra("resultData")
        }

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        createNotificationChannel()

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "capture_channel")
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle("Pool Aim Assistant")
            .setContentText("Captura optimizada activa")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                10,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(10, notification)
        }

        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager

            projection = manager.getMediaProjection(resultCode, data)

            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels

            analysisThread = HandlerThread("PoolAimAnalysis").also {
                it.start()
            }
            analysisHandler = Handler(analysisThread!!.looper)

            reader = ImageReader.newInstance(
                width,
                height,
                PixelFormat.RGBA_8888,
                2
            )

            reader?.setOnImageAvailableListener({ imageReader ->

                val image = imageReader.acquireLatestImage()
                    ?: return@setOnImageAvailableListener

                var bitmap: Bitmap? = null
                var smallBitmap: Bitmap? = null

                try {
                    val now = SystemClock.elapsedRealtime()

                    // Analizar como máximo una imagen cada 700 ms.
                    if (now - lastAnalysisTime < 700) {
                        return@setOnImageAvailableListener
                    }

                    lastAnalysisTime = now

                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride

                    val rowPadding =
                        (rowStride - pixelStride * image.width) / pixelStride

                    val paddedWidth = image.width + rowPadding

                    bitmap = Bitmap.createBitmap(
                        paddedWidth,
                        image.height,
                        Bitmap.Config.ARGB_8888
                    )

                    bitmap.copyPixelsFromBuffer(buffer)

                    // Reducir la imagen para ahorrar memoria y procesador.
                    val scale = minOf(
                        1f,
                        480f / image.width.toFloat()
                    )

                    val matrix = Matrix()
                    matrix.postScale(scale, scale)

                    smallBitmap = Bitmap.createBitmap(
                        bitmap,
                        0,
                        0,
                        image.width,
                        image.height,
                        matrix,
                        false
                    )

                    val detected = detector.detect(smallBitmap)

                    android.util.Log.d(
                        "PoolAim",
                        "Puntos detectados: ${detected.size}"
                    )

                } catch (e: Exception) {
                    android.util.Log.e(
                        "PoolAim",
                        "Error al analizar imagen",
                        e
                    )
                } finally {
                    smallBitmap?.recycle()
                    bitmap?.recycle()
                    image.close()
                }

            }, analysisHandler)

            projection?.registerCallback(
                callback,
                analysisHandler
            )

            display = projection?.createVirtualDisplay(
                "PoolAimCapture",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface,
                null,
                analysisHandler
            )

        } catch (e: Exception) {
            android.util.Log.e("PoolAim", "Error de captura", e)
            releaseCapture()
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "capture_channel",
                "Captura de pantalla",
                NotificationManager.IMPORTANCE_LOW
            )

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun releaseCapture(stopProjection: Boolean = true) {

        display?.release()
        display = null

        reader?.setOnImageAvailableListener(null, null)
        reader?.close()
        reader = null

        val current = projection
        projection = null

        if (stopProjection && current != null) {
            current.unregisterCallback(callback)
            current.stop()
        }

        analysisHandler = null

        analysisThread?.quitSafely()
        analysisThread = null
    }

    override fun onDestroy() {
        releaseCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
