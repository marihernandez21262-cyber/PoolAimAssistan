
package com.example.poolaimassistant

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var trajectoryView: TrajectoryOverlayView? = null
    private var statusText: TextView? = null

    private val handler = Handler(Looper.getMainLooper())

    private val updateTask = object : Runnable {
        override fun run() {
            val detected = AimData.balls
            trajectoryView?.updateBalls(detected)
            statusText?.text =
                "Bolas detectadas: ${detected.size}\n" +
                "Bola blanca: ${if (AimData.whiteBall != null) "Sí" else "No"}"

            handler.postDelayed(this, 300)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createTrajectoryLayer()
        showPanel()
        handler.post(updateTask)
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun createTrajectoryLayer() {
        val view = TrajectoryOverlayView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.START
        wm.addView(view, params)
        trajectoryView = view
    }

    private fun panelParams(): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 120
        }

    private fun showPanel() {
        removeBubble()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(25, 35, 48))
        }

        val title = TextView(this).apply {
            text = "POOL AIM ASSISTANT"
            textSize = 15f
            setTextColor(Color.YELLOW)
            setPadding(8, 8, 8, 10)
        }

        title.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = layout.layoutParams as WindowManager.LayoutParams
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = p.x
                        startY = p.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (event.rawX - touchX).toInt()
                        p.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(layout, p)
                        return true
                    }
                }
                return false
            }
        })

        layout.addView(title)

        statusText = TextView(this).apply {
            text = "Esperando captura..."
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(8, 6, 8, 10)
        }
        layout.addView(statusText)

        layout.addView(Button(this).apply {
            text = "OCULTAR"
            setOnClickListener { hidePanel() }
        })

        layout.addView(Button(this).apply {
            text = "CERRAR"
            setOnClickListener { stopSelf() }
        })

        wm.addView(layout, panelParams())
        panel = layout
    }

    private fun hidePanel() {
        panel?.let {
            if (it.isAttachedToWindow) wm.removeView(it)
        }
        panel = null
        showBubble()
    }

    private fun showBubble() {
        removeBubble()

        val dot = TextView(this).apply {
            text = "●"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.YELLOW)
            setPadding(14, 8, 14, 8)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(25, 35, 48))
                setStroke(3, Color.YELLOW)
            }
            setOnClickListener {
                removeBubble()
                showPanel()
            }
        }

        wm.addView(dot, panelParams())
        bubble = dot
    }

    private fun removeBubble() {
        bubble?.let {
            if (it.isAttachedToWindow) wm.removeView(it)
        }
        bubble = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateTask)

        panel?.let {
            if (it.isAttachedToWindow) wm.removeView(it)
        }
        panel = null
        removeBubble()

        trajectoryView?.let {
            if (it.isAttachedToWindow) wm.removeView(it)
        }
        trajectoryView = null
        statusText = null

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
