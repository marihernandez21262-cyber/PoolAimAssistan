
package com.example.poolaimassistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val requestOverlay = 501
    private val requestCapture = 502

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(25, 25, 25, 25)
            setBackgroundColor(0xFF101722.toInt())
        }

        root.addView(TextView(this).apply {
            text = "POOL AIM ASSISTANT"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFD36A.toInt())
        })

        root.addView(Button(this).apply {
            text = "ACTIVAR VENTANA FLOTANTE"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(
                        Intent(this@MainActivity, OverlayService::class.java)
                    )
                } else {
                    val permission = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivityForResult(permission, requestOverlay)
                }
            }
        })

        root.addView(Button(this).apply {
            text = "INICIAR CAPTURA DE PANTALLA"
            setOnClickListener {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE)
                    as MediaProjectionManager

                startActivityForResult(
                    manager.createScreenCaptureIntent(),
                    requestCapture
                )
            }
        })

        root.addView(Button(this).apply {
            text = "MESA DE PRÁCTICA"
            setOnClickListener {
                showPractice()
            }
        })

        setContentView(root)
    }

    private fun showPractice() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101722.toInt())
            setPadding(8, 8, 8, 8)
        }

        root.addView(Button(this).apply {
            text = "VOLVER"
            setOnClickListener {
                showHome()
            }
        })

        root.addView(PracticeTableView(this), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))

        setContentView(root)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == requestOverlay &&
            Settings.canDrawOverlays(this)
        ) {
            startService(Intent(this, OverlayService::class.java))
        }

        if (requestCode == requestCapture &&
            resultCode == RESULT_OK &&
            data != null
        ) {
            val serviceIntent = Intent(
                this,
                ScreenCaptureService::class.java
            ).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }

            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        }
    }
}
