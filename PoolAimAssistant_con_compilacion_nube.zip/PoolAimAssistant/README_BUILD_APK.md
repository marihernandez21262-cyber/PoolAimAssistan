# PoolAimAssistant

## Compilar el APK en GitHub Actions

1. Crea una cuenta gratuita en https://github.com/signup.
2. Crea un repositorio nuevo y súbele el contenido de esta carpeta (la carpeta `.github` también).
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Build Android APK** y pulsa **Run workflow** (o espera a que termine el primer push).
5. Cuando el trabajo termine en verde, abre la ejecución y descarga el artefacto **PoolAimAssistant-debug**.
6. Descomprime el ZIP descargado. El instalador es `app-debug.apk`.

Este flujo compila el proyecto en un runner de GitHub con JDK 21 y Gradle 8.7. El APK resultante es de depuración, no está firmado para distribución en Play Store.

## Estado funcional

El flujo de compilación no significa que las funciones de detección y puntería estén validadas. Deben probarse en el teléfono con capturas reales de la mesa y ajustarse antes de considerar terminada la aplicación.
