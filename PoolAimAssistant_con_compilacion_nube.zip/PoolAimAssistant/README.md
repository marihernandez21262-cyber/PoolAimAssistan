# Pool Aim Assistant (Android)

Proyecto inicial Android Studio, Kotlin.

## Qué incluye
- Ventana flotante sobre otras aplicaciones (permiso Android).
- Panel flotante movible.
- Guía larga, tres líneas, punto de contacto ilustrativo y trayectoria de referencia.
- Modo de rebote esquemático.
- Controles para ajustar el ángulo.

## Limitaciones importantes
Esta versión NO detecta bolas automáticamente y NO calcula la física real de 8 Ball Pool.
Las líneas se dibujan como guías de alineación manual sobre la pantalla. El rebote es ilustrativo,
no una predicción exacta de la mesa. Para detección real se requiere captura de pantalla con
MediaProjection y un módulo de visión por computadora, además del consentimiento del usuario.

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `PoolAimAssistant` en Android Studio.
3. Espera la sincronización de Gradle.
4. Ejecuta en un teléfono Android 6.0 o superior.
5. Concede el permiso «Mostrar sobre otras apps».
6. Pulsa «Activar ventana flotante».
7. Abre 8 Ball Pool y mueve el panel desde su encabezado.

## Controles
Los botones cambian la dirección y muestran/ocultan las guías. El panel se mueve arrastrando
el encabezado «POOL AIM • MOVER».
